import inspect

import autoeagle

if __name__ == "__main__":
    with autoeagle.core.ScriptWriter() as scr:
        scr.display_layers(["Top"])
